function fdParobj = putlambda(fdParobj, lambda)
%  Replace the lambda parameter

fdParobj.lambda = lambda;